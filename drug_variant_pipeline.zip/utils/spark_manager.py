from pyspark.sql import SparkSession

class SparkSessionManager:
    _spark = None

    @classmethod
    def get_spark(cls):
        if cls._spark is None:
            cls._spark = SparkSession.builder                 .appName("DrugVariantPipeline")                 .getOrCreate()
        return cls._spark