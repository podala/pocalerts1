class PPLCalculator:
    def apply(self, df, config):
        return df