class WACCalculator:
    def apply(self, df, config):
        return df