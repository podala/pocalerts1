class PPACalculator:
    def apply(self, df, config):
        return df