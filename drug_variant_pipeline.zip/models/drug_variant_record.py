from dataclasses import dataclass, asdict
from typing import Dict, Any

@dataclass
class DrugVariantRecord:
    id: str
    drugKey: str
    drugName: str
    clientName: str
    opportunityId: str
    therapeuticClass: str
    partitionKey: str
    ttl: int
    PostShift: Dict[str, Dict[str, Any]]
    Base: Dict[str, Dict[str, Any]]
    MAF: Dict[str, Dict[str, Any]]
    PPL: Dict[str, Dict[str, Any]]
    WAC: Dict[str, Dict[str, Any]]
    PPA: Dict[str, Dict[str, Any]]

    def to_dict(self) -> dict:
        return asdict(self)