class CosmosDBWriter:
    _instance = None

    def __init__(self, config):
        self.config = config

    @classmethod
    def get_instance(cls, config):
        if cls._instance is None:
            cls._instance = cls(config)
        return cls._instance

    def write(self, json_rdd):
        print("Writing to Cosmos DB...")